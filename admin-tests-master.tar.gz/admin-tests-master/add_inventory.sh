#!/bin/bash
git submodule add $1 $2
git submodule update --init --recursive
git submodule update --remote