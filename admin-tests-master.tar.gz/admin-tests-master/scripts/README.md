# Script description


## Test-ODBCConnection.ps1

compatibility

- Windows 10	Yes
- Windows Server 2012	Yes
- Windows Server 2012 R2	Yes
- Windows Server 2008 R2	Yes
- Windows Server 2008	Yes
- Windows Server 2003	No
- Windows Server 2016	No
- Windows 8	Yes
- Windows 7	Yes
- Windows Vista	No
- Windows XP	No
- Windows 2000	No