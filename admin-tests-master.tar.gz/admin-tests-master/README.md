# Testing
<!--TO clone and update this project and submodule, run:-->

<!--```-->
<!--git clone https://code.siemens.com/pkiservices/ansible/ansible-tests/pki3-tests.git-->
<!--git submodule update --init --recursive-->
<!--git submodule update --remote-->
<!--```-->

first add inventory with

```sh
./add_inventory.sh <Inventory_URL> <inventories/folder>
```

> if you're not sure which inventory to use, ask your infrastructure guys

## Plays and variable description

You need *tower_test_runner* value in whatever inventory you use

### check_port_opened.yml

**ports_opened** - ports that must be opened

so in your host/group_vars you will specify it like

```yaml
ports_opened:
  - 5986
  - 80
```

### check_port_closed.yml

**ports_closed** - ports that must be closed

```yaml
ports_closed:
  - 23
```

**You should use it in every group_vars, as telnet (port 23) should be closed everywhere!**

### check_logs.yml

**log_check_cannot_contain**

  **.log** - log file to search thru

  **.keyword** - keyword that log **cannot** contain

**log_check_must_contain**

  **.log** - log file to search thru

  **.keyword** - keyword that log **must** contain

and you can use it in your group/host_vars following way

```yaml
log_check_cannot_contain:
  - { log: "L:\\logfiles\\server_log.txt", keyword: "error" }
  - { log: "L:\\logfiles\\server_log.txt", keyword: "warning" }
log_check_must_contain:
  - { log: "L:\\logfiles\\server_log.txt", keyword: "hardening" }
```

### check_script_output.yml

run script and check output for certain keyword that must (or must not) be there

```yaml
script_output_must_contain:
  - { script: "somescript", keyword: "OK" }
script_output_cannot_contain:
  - { script: "somescript", keyword: "FAIL"}
```

### check_mssql_db_accessible.yml (Windows only)

```yaml
db_win_to_check:
  - primedesignerdb
  - primeexplorerdb
```

### check_process_running.yml

**process_running** - process that must be up and running on server

```yaml
process_running:
  - MSSQLSERVER
  - SQLSERVERAGENT
  - SQLTELEMETRY
  - SQLWriter
```

### check_url_simple.yml

**check_urls_simple** - specify URL which should be reachable (return code 200)

can be used in group/host_vars as

```yaml
check_urls_simple:
  - https://172.20.83.147:8443/prime_explorer/start.jnlp
```

but as the best practice you should use

```yaml
check_urls_simple:
  - https://{{ ansible_host }}:{{ tomcat_port }}/prime_explorer/start.jnlp
```

### check_url_local_cert.yml

check url (with certificate) on localhost 

used for PPKI

> curl -k  -s --url {{ ppki_ca_url }} --cert {{ cert_nickname }} --pass {{ ejbca_healthcheck_cert_pass }}

### check_sshkey_quality.yml

check if SSH keys comply with following:

* they are 4096 bits
* they are only in /etc/ssh or /home

*Background:*

we have following format of keys

```
2048 SHA256:qXsF72isRqPjPZ3F+17ot+87rgChIeH71nayzAaeE/k john@example.com (RSA)
256 SHA256:5s8esvh6CQz1tw7DzMhOhBcEmxPVpEpLkXZ/9j20DbA john@example.com (ED25519)
```

* DSA: It’s unsafe and even no longer supported since OpenSSH version 7, you need to upgrade it!
* RSA: It depends on key size. If it has 3072 or 4096-bit length, then you’re good. Less than that, you probably want to upgrade it. The 1024-bit length is even considered unsafe.
* ECDSA: It depends on how well your machine can generate a random number that will be used to create a signature. There’s also a trustworthiness concern on the NIST curves that being used by ECDSA.
* Ed25519: It’s the most recommended public-key algorithm available today but you should check compatibility with your client (putty,mobaxterm, etc..)

### galera_cluster_check.yml

just define db to test

```yaml
mysql_db: "ejbca" 
```

### check_url_local_cert.yml

```yaml
url_local_with_cert:
  - url: someurl
  - user: myuser
  - password: mypass
  - client_certficate: mycert
```

### checksum_control.yml

define file and expected checksum

```
checksum_files:
  - { path: "/usr/local/qualys/cloud-agent/bin/qualys-cloud-agent", checksum: "8594920f972b3f104cc9b4b24aff296474ee2144" } 
```

to obtain checksum run

> Get-Filehash -path C:\Program Files (x86)\Qualys\QualysAgent\QualysAgent.exe -algorithm SHA1

or 

> sha1sum /usr/local/qualys/cloud-agent/bin/qualys-cloud-agent

### win_updates.yml

just run it against group/host of win server(s) and it should fail when there are any updates waiting to be applied

<!--### check_disk_size.yml TODO-->

<!--can be used with-->

<!--```-->
<!--disk_size_check:-->
<!--  - { mount: "/boot", treshold: "70%" }-->
<!--```-->

<!--where we expect that /home on machine didn't fill more than 80% of disk.-->

# How to run Examples:

check URLs on all windows servers

> ansible-playbook -i inventories/Net_83/ -l win_servers plays/check_url_simple.yml

check MSSQL is running on all primesql servers

> ansible-playbook -i inventories/Net_83/ -l primesql_servers plays/check_process_running.yml

check if MSSQL db/schema is accessible

> ansible-playbook -i inventories/Net_83/ -l win_servers plays/check_mssql_db_accessible.yml -e "ansible_python_interpreter=/usr/bin/python"

check if desired ports are opened

>  ansible-playbook -i inventories/Net_83/ -l win_servers plays/check_port_opened.yml

check all ports (that should be closed.. like telnet) are closed on win servers

> ansible-playbook -i inventories/Net_83/ -l win_servers plays/check_port_closed.yml

check logs on all win servers

>  ansible-playbook -i inventories/Net_83/ -l win_servers plays/check_logs.yml

check SSH keys if they comply with security requirements (4096 bits and only in /etc/ssh and /home)

>  ansible-playbook -i inventories/Net_83/hosts -l 83linux plays/check_sshkey_quality.yml


# Status of playbooks

```
check_logs.yml - OK, tested
check_port_closed.yml - OK, tested
check_process_running.yml - OK, tested (only Tomcat vars missing)
check_url_simple.yml - OK, tested
check_mssql_db_accessible.yml - OK, tested
check_port_opened.yml - OK, tested
check_url_complex.yml - not tested, but should be extended more anyway depending on requirements
check_sshkey_quality.yml - OK, tested

check_script_output.yml - NOT TESTED
```

## win patch test

to test: 83wintest  172.20.83.146



